# Changelog — @ai-matrx/records

## 0.3.0

**The anonymous lane, wired to the doors that actually exist.** This package
named a door `custom.anon_record_write`, which the store never had — so
`FormRunner` told every person that a public form's link was "pending" for a
lane that had already shipped. W4-ANON landed as SEVEN doors, and they are all
here now: `anonTokenIssue` / `anonTokenVerify` / `anonTokenRevoke` (an embed
token carries ONE decision, read or write, and an exact origin list), `anonWrite`
(the stranger's write — the TOKEN supplies the organization, and what it makes is
a quarantined submission, never a record), `anonCapture` (the SIGNED-IN offline
path, deduplicated on a key the client mints) and `anonPublish`. A screen calling
a live feature pending is the same silent failure as one calling a missing
feature live.

**Work.** `workStates`, `workTemplateRefusal` / `workTemplateDeclare` /
`workTemplateInstantiate` / `workTemplateShape` / `workInstantiationShape`,
`workWhoseTurn`, `workHasAssignment`, `workAssignmentFields`,
`workTakeAssignment`, `workTransitionRefusal`, and the slots:
`workSlotsDeclare`, `workSlotHold`, `workSlotRelease`, `workSlotHolds`,
`workSlotExpire`. One hold per slot is a UNIQUE INDEX in the database, so a
second hold comes back as `already_exists` carrying the index that refused it.

**The trust doors, and they are `iam`'s, not the store's.** `isExternalPrincipal`,
`externalPrincipalCard`, `externalPrincipalReach`, `publishBindingCreate`,
`publishBindingRevoke`, `resolvePublishBinding`, `worldPublishGapNotice`,
`publishToWorld`. They are named by hand in `core/doors.ts` rather than
generated, because `pnpm records:generate` reads `custom` and only `custom` — a
census of it says nothing true about `iam`. `RecordsDataSource.rpc` gained an
optional third argument, `{ schema }`, which a supabase-js host routes to
`client.schema(schema).rpc(...)`; every existing call is unchanged.

New types: `WorkState`, `WorkGraph`, `WorkInstantiation`, `WorkTurn`,
`WorkSlotHold`, `WorkAssignmentField`, `AnonTokenBinding`,
`ExternalPrincipalCard`, `PublishBinding`, `ResolvedPublishBinding`.

**Two vocabularies this package had wrong, found by writing a Field the store
refused.** `FIELD_SENSITIVITIES` read `standard · sensitive · secret`; the store
has always wanted `public · internal · confidential · restricted`, which is also
what the knob `custom/field_sensitivity_levels` keys off — so the two could
never have agreed. And `Field.context_policy` was typed as `Delivery`
(`inline · on_demand · auto`), which is a different question: delivery is how
much of a merge field's value rides into a turn, while FLD-12's context policy
is whether an agent may see a Field's values at all, in the store's own words
`include · summarize · exclude · on_request`. Both are corrected, and
`ContextPolicy` is now its own exported type. Neither was generated, which is
why neither was caught by `pnpm check:store-registry`.

`src/store.generated.ts` regenerated from the live store.

## 0.2.0

**Reads go through the read door.** `recordRead` calls `custom.read_record` and
`list` calls `custom.read_records` instead of selecting `custom.record`, so the
store decides which rows a reader may see and which fields of them: a masked
field comes back present-and-null with the store's own reason in `hidden`
(`_hidden`, unfolded for you). `query` materialises through the same doors, and
its as-of reads now call `custom.query_record_as_of` / `custom.query_table_as_of`
— both clocks — instead of filtering `updated_at` itself and refusing the world
clock by name.

Shapes that changed with it: `list` and `query` answer `ReadRow[]`
(`{ id, document, level, hidden }`) rather than raw store rows, `RecordRead` is
`{ record_id, document, hidden, computed }`, and `useRecords` lost
`includeDeleted` — the read door reads live records only, and there is no door
that answers otherwise.

New refusal class: `stale_read` (`40001`), which is `custom.has_visibility_at`
refusing to answer from a snapshot older than a write the reader has already
observed. It is the one refusal worth retrying.

**A store defect this found and fixed** (`db/migrations/campaign/vis25_the_owner_arm_on_the_read_door.sql`,
applied to the main database): `custom.has_visibility` had no VIS-25 owner arm,
so the record you had just written was yours to `custom.read_records` and not
yours to `custom.read_record` — the list offered the row and the door slammed.

## 0.1.1

First working release: the types root, the headless `/core` client over the
store's doors, the `/react` binding, the generated store registry
(`pnpm records:generate` / `check:store-registry`) and the real-door suite that
runs against the live rehearsal branch inside an always-rolled-back transaction.

Two defects the suite found in the mirror and fixed:

- The document-size prediction measured `JSON.stringify` bytes; the store
  measures the JSONB text, which puts a space after every `:` and every `,`. On
  an 18-key document the two sentences disagreed by 35 bytes. The mirror now
  renders the way Postgres does.
- The mirror predicted refusals for `ver`, `actor`, `on_behalf_of` and `at`.
  The store never raises them: `custom.stamp_value_envelopes` and
  `custom.value_versions` overwrite all four with the truth BEFORE
  `custom.value_envelope_refusal` looks. Those four predictions are gone —
  a sentence the store never says is a defect in the mirror.
