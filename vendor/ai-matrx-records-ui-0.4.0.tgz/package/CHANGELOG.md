# Changelog — @ai-matrx/records-ui

## 0.3.0

**The last eight, and the package is complete at thirty-one components.**

`RecordChat` (SCR-26) reuses the platform's ONE chat surface instead of shipping
a second: it builds the context — the record through the read door, each value
carrying its Field's unit and format, the masked fields named, the `secret` and
`on_demand` ones held back with the reason — and hands it to a new `chat` port
that matrx-frontend fills with `AgentConversationColumn`.

`EnrichPanel` (SCR-27) drives per-field AI fill off the Fields' own
`source = agent` and `review_interval_days`, dates each value from its own
envelope rather than the row, shows VAL-8 provenance on every value (including
which person an agent acted for), and sends the fill through the server's
`records` tool via a new `enrich` port — because a browser stamping itself
`agent` would be a browser claiming to be one.

`ChecklistRunner` (SCR-28) instantiates a declarative template as REAL RECORDS
in one act. `BookingSlots` (SCR-29) holds the slot before it takes the details
and lets the database decide a double-booking. `CaptureSheet` (SCR-30) is the
offline capture contract: the client mints the id before the first attempt and
`custom.anon_capture` deduplicates every replay onto the same record.

`PortalShell` (SCR-23), `PublicViewPage` (SCR-24) and `EmbedFrame` (SCR-25) are
the outsider's three surfaces, over `iam`'s external principal and publish
binding and over the embed token handshake.

New host ports: `chat`, `enrich`, `captureQueue`. Requires
`@ai-matrx/records` 0.3.0.

**A RACE EVERY SEED-TAKING COMPONENT HAD, closed as a class.** `DocTemplate`,
`ViewBar`, `FormBuilder`, `DashboardCanvas` and `ActionInbox` all read what
exists, worked out what was missing, and wrote it — from a loader whose identity
changes when its inputs settle. Against a slower store the second run read a
list the first was still writing into, and seeded the same thing twice: two
identical "Agreement" templates, two buttons with one name. A check against the
server's list is not a lock. `useSeedGuard` claims each seed name once per
mount, and all five now use it.

**Four more defects this wave found and closed.** `FormRunner` told every person that
a public form's link was "pending" for a door named `custom.anon_record_write`
that never existed, while the real anonymous lane had shipped — it now names
`custom.anon_write` and tells a person the true next step (issue an embed). And
the demo harness read a rehearsal copy that was missing a third of the doors
this package now calls; it reads the one live store, and stands its own table,
fields and records up rather than depending on rows somebody typed once. The
two vocabulary drifts behind `RecordChat`'s context rules — a Field's
sensitivity words and its context-policy words — were corrected in
`@ai-matrx/records` 0.3.0; `RecordChat` holds back `confidential` and
`restricted` values and FLD-12's `exclude` and `on_request` fields, and names
every one of them rather than letting an agent answer around a gap.

## 0.2.0

`DocTemplate`, `DocRender` and `SignBlock` (SCR-20/21/22): a template is saved
through `custom.doc_template_save`, a render is frozen once and printed through
`@ai-matrx/print`, and a signature is checked against the exact bytes that were
signed (`custom.doc_signature_intact`). A token the Table cannot answer is named
before anything is rendered.

Every component now reads through `@ai-matrx/records` 0.2.0's read door, so a
row is the store's masked document and a masked field is present-and-null with
its own reason. `useRecordVersion` reads the edited record's version from
`custom.io_revisions`, and `useSystemTable` adds Fields a package Table grew to
organizations that already hold a copy.

One store defect was found by wiring this and fixed on the main database:
`custom.read_record` refused records `custom.read_records` had just listed,
because the one-record door asked a narrower question than its own list sibling.
It now asks `iam.has_access_for`, the platform's one access question
(`matrx-frontend/migrations/campaign/w6_ui_the_read_door_asks_the_one_access_question.sql`).

## 0.1.0

First release: `Grid`, `RecordForm`, `FieldEditor`, `TableSettings`,
`RelationPicker`, `Peek`, `ImportWizard`, `ExportMenu` and
`CustomFieldsSection`, plus the `RecordsUiProvider` rights port and the shared
refusal surface. Every one of them is proven headlessly against the rehearsal
branch by `pnpm test`.
