# @ai-matrx/records

THE headless client of the AI Matrx record store: the Table / Field / Rule /
Record / Relation / Home types, the closed vocabularies and refusal codes read
from the store ITSELF, the typed calls over the store's doors and nothing else,
the merge-field declaration, a validation mirror that predicts only what the
store's own triggers refuse, and a result envelope that never throws.

The package ships the types root, the headless `/core` and the React binding
`/react`. `@ai-matrx/records-ui` renders it; nothing else talks to the store.

**The one rule this package lives by:** the client mirrors the store's contract
and never re-implements a rule the store enforces. Where the store refuses, this
package surfaces the store's own sentence — never a translation of it.

```ts
import {
  type Table, type Field, type StoredRecord, // the shapes
  type ValueEnvelope,                        // ver · src · actor · on_behalf_of · at · absent · alternates · dated
  PARITY_FIELD_TYPES,                        // the 13 field types, read from custom.parity_field_types()
  ACTOR_VOCABULARY,                          // exactly: user, agent, system
  ABSENCE_REASONS,                           // exactly: never asked, none, refused, conflicting
  STORE_DOORS, STORE_REFUSAL_CODES,          // GENERATED from pg_proc on the live store
} from "@ai-matrx/records";
```

## /core — the typed client over the doors

```ts
import { createRecordsClient } from "@ai-matrx/records/core";

const records = createRecordsClient({
  dataSource: supabase,                  // structural subset of SupabaseClient
  organizationId: orgId,                 // the store is keyed (organization_id, id)
  onError: (e) => report(e),             // OPTIONAL — the default screams to console
});

const written = await records.recordWrite({ table_id, data: { title: "Acme", owner: personId } });
const rows    = await records.list({ table_id, limit: 50 });
const one     = await records.recordRead({ record_id, withComputed: true });
const moved   = await records.recordUpdate({ record_id, patch: { title: "Acme Inc" }, expectedVersion: 3 });

if (!moved.ok && moved.error.code === "stale_write") {
  // The store's own words, plus the conflict field by field.
  moved.error.message;  // "Someone else changed this record while you were working on it. …"
  staleWriteDetail(moved.error); // { expected_version, current_version, contested_fields }
}
```

Nothing here throws, and nothing here invents an answer. A door the store does
not have yet is answered `door_absent`, naming the door AND the lane that owes
it — `metadataSearch`, `fieldPropose`, `tablePropose` and `mergeFieldResolve`
refuse today rather than returning an empty list that would read like "there is
nothing".

## The mirror — what the store is about to say, said half a second earlier

```ts
import { predictWriteRefusals } from "@ai-matrx/records/core";

const problems = predictWriteRefusals({ fields, document, recordType });
// [{ field_key: "amount", sqlstate: "23514", predicted_by: "custom.validate_values",
//    message: "Amount has to be at least 1" }]
```

This is NOT validation — the store validates, inside the write door, and cannot
be bypassed. The mirror only says what the store is about to say, in the store's
exact sentence, and it says NOTHING where it cannot see (option membership,
relation targets, anything needing a query). Silence means "ask the store".

## /react — bind once, then hooks

```tsx
import {
  RecordsProvider, useTables, useFields, useRecords, useRecord, useRecordMutation,
} from "@ai-matrx/records/react";

<RecordsProvider client={records}>{children}</RecordsProvider>;

const { tables } = useTables();
const { fields } = useFields(table_id);
const { rows, total, live, liveOffReason } = useRecords({ table_id, pageSize: 50 });
const { write, update, remove, conflict } = useRecordMutation();
```

`live` is never quietly false: when realtime is not bound, `liveOffReason` says
why in a sentence a screen can show.

## The generated half

`src/store.generated.ts` is written by `pnpm records:generate` from the live
store's own catalogue — the vocabularies from the store's vocabulary functions,
the field types from `custom.parity_field_types()`, the doors from `pg_proc`,
the kernel ids from the kernel rows, the tokens from `platform.entity_types`.
`pnpm check:store-registry` exits non-zero the moment this package and the store
disagree, which is how a door another lane added shows up as a red check rather
than as a runtime surprise.

## The suite

`pnpm test` runs against the live rehearsal branch. Every case is one
transaction that always ends in `rollback`: inside it the suite opens the
product switch, grants only what its own half needs, and sets
`request.jwt.claims` to the campaign's test identity (`test@test.com`) — so every
call goes through the real doors, the real triggers and the real guards, as a
real identity, and the branch is byte-identical afterwards (the last test
re-reads it from a fresh connection and proves it). The red half is the same
calls without that standing, asserted by the store's message text.

## Commands

| Command | What it does |
|---|---|
| `pnpm records:generate` | Rewrite `src/store.generated.ts` from the live store |
| `pnpm check:store-registry` | Fail when this package and the store disagree |
| `pnpm test` | The real-door suite |
| `pnpm build` | tsup → `dist` (esm + cjs + d.ts), then the client boundary stamp |
| `pnpm check:package` | build · exports agreement · publint · tarball canary |
