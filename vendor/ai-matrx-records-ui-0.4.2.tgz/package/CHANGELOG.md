# Changelog — @ai-matrx/records-ui

## 0.4.2

Uses the same bounded live-store wait as `@ai-matrx/records`, so a legitimate
overlapping rollback-only verification cannot make the demo proof fail after
twenty seconds.

### Consumer action

None beyond taking `latest`; the public API is unchanged.

## 0.4.1

Restores monotonic versioning after a concurrent release plan overwrote the
already-staged 0.4.0 version, and shares the serialized record-store release
lane with `@ai-matrx/records`.

### Consumer action

None beyond taking `latest`; the 0.4.0 API remains intact.

## 0.3.2

Automatic changed-only republish (docs/metadata drift since the last tag — see
`git diff npm/records-ui/v0.3.1..npm/records-ui/v0.3.2 -- apps/shared/records-ui`).
No source changes intended and no consumer action required.

## 0.4.0

**`recordsDataSource` honours the schema the CALLER named, and the two page
assemblies get their first headless proof.**

0.3.1's adapter routes every `rpc` to one fixed schema (`custom` by default).
That is right for the store's own doors and wrong for the trust doors:
`@ai-matrx/records`' `trustDoor` says `iam` out loud — the external principal and
the publish binding live there — and a fixed-schema adapter sends them to
`custom`, where PostgREST answers PGRST202 naming a schema the caller never
asked for. The adapter now reads `options.schema` per call and falls back to the
second argument (still `custom`) only when a call says nothing, which no caller
in `@ai-matrx/records` does. The port already specified this: "A host binding
supabase-js routes this to `client.schema(options.schema).rpc(fn, args)`".

`TablesHome` and `TablePage` shipped in 0.3.1 with no assertion of their own.
Three now run against the live store in `demo/smoke.test.tsx`: the four lanes
drawn by name with a real table in one of them and `New table` offered; the
table page's records plus its five admin rails, with the settings rail really
opening the panel; and the same page giving a plain member the records and NONE
of the administering controls — absent, not disabled.

**THE WALK, and the three defects walking it found.** `demo/walk.test.tsx` runs
the whole product against the live store in one file — declare a table with three
field types, write a record through the generated form, open the table page and
peek the record, save a view, file an agent's field proposal and accept it,
export the CSV, then walk the same table as a plain member and be offered nothing
to administer. Seven cases, green, and the table it makes is soft-deleted after.
It found:

· **A table nobody had saved a view for showed NO RECORDS.** A view is a record,
  so a brand-new table has none, and `TablePage` then rendered its own honest
  "Waiting for this table's views" and nothing else — a dead end on the first
  table anybody makes. The page now seeds `DEFAULT_VIEW_NAME` ("All records",
  grid), an ordinary saved-view record a person can rename or delete, never a
  hidden built-in mode. A host with its own idea passes `seedViews`.

· **`ProposedChange.table` was required for all three acts and unfillable for
  two.** `update` and `remove` name a record and ignore `table`, so a proposer
  wanting to change an existing record had to supply the id of the kernel Table
  that record lives in — a fact the client has no door to ask for. It is optional
  now, and an `add` without it is refused by name instead of writing nowhere.

· **The demo harness's pages were dead in a browser while `pnpm test` was
  green.** Two copies of React in one vite graph (the demo's own dependency tree
  plus the workspace's, through design-system and alchemy): React reported
  "Invalid hook call … more than one copy of React" and the page rendered
  nothing. `demo/vite.config.ts` now dedupes react and react-dom.

**Consumer action:** none. `recordsDataSource(client)` is unchanged at the call
site; a host that deliberately wants a different fallback passes it second.

## 0.3.1

Ships the canonical `TablesHome`, `TablePage`, `RecordsMount`, and table-creation helpers
that were added after 0.3.0 was tagged. The real-store demo now shares the package-wide
verification lock, and the packed-artifact canary verifies `@ai-matrx/records-ui` itself
instead of accidentally re-verifying the headless `@ai-matrx/records` package.

**Consumer action:** replace temporary workspace or source references with
`@ai-matrx/records-ui@latest`; no API rename is required.

## 0.3.0

**The last eight, and the package is complete at thirty-one components.**

`RecordChat` (SCR-26) reuses the platform's ONE chat surface instead of shipping
a second: it builds the context — the record through the read door, each value
carrying its Field's unit and format, the masked fields named, the `secret` and
`on_demand` ones held back with the reason — and hands it to a new `chat` port
that matrx-frontend fills with `AgentConversationColumn`.

`EnrichPanel` (SCR-27) drives per-field AI fill off the Fields' own
`source = agent` and `review_interval_days`, dates each value from its own
envelope rather than the row, shows VAL-8 provenance on every value (including
which person an agent acted for), and sends the fill through the server's
`records` tool via a new `enrich` port — because a browser stamping itself
`agent` would be a browser claiming to be one.

`ChecklistRunner` (SCR-28) instantiates a declarative template as REAL RECORDS
in one act. `BookingSlots` (SCR-29) holds the slot before it takes the details
and lets the database decide a double-booking. `CaptureSheet` (SCR-30) is the
offline capture contract: the client mints the id before the first attempt and
`custom.anon_capture` deduplicates every replay onto the same record.

`PortalShell` (SCR-23), `PublicViewPage` (SCR-24) and `EmbedFrame` (SCR-25) are
the outsider's three surfaces, over `iam`'s external principal and publish
binding and over the embed token handshake.

New host ports: `chat`, `enrich`, `captureQueue`. Requires
`@ai-matrx/records` 0.3.0.

**A RACE EVERY SEED-TAKING COMPONENT HAD, closed as a class.** `DocTemplate`,
`ViewBar`, `FormBuilder`, `DashboardCanvas` and `ActionInbox` all read what
exists, worked out what was missing, and wrote it — from a loader whose identity
changes when its inputs settle. Against a slower store the second run read a
list the first was still writing into, and seeded the same thing twice: two
identical "Agreement" templates, two buttons with one name. A check against the
server's list is not a lock. `useSeedGuard` claims each seed name once per
mount, and all five now use it.

**Four more defects this wave found and closed.** `FormRunner` told every person that
a public form's link was "pending" for a door named `custom.anon_record_write`
that never existed, while the real anonymous lane had shipped — it now names
`custom.anon_write` and tells a person the true next step (issue an embed). And
the demo harness read a rehearsal copy that was missing a third of the doors
this package now calls; it reads the one live store, and stands its own table,
fields and records up rather than depending on rows somebody typed once. The
two vocabulary drifts behind `RecordChat`'s context rules — a Field's
sensitivity words and its context-policy words — were corrected in
`@ai-matrx/records` 0.3.0; `RecordChat` holds back `confidential` and
`restricted` values and FLD-12's `exclude` and `on_request` fields, and names
every one of them rather than letting an agent answer around a gap.

## 0.2.0

`DocTemplate`, `DocRender` and `SignBlock` (SCR-20/21/22): a template is saved
through `custom.doc_template_save`, a render is frozen once and printed through
`@ai-matrx/print`, and a signature is checked against the exact bytes that were
signed (`custom.doc_signature_intact`). A token the Table cannot answer is named
before anything is rendered.

Every component now reads through `@ai-matrx/records` 0.2.0's read door, so a
row is the store's masked document and a masked field is present-and-null with
its own reason. `useRecordVersion` reads the edited record's version from
`custom.io_revisions`, and `useSystemTable` adds Fields a package Table grew to
organizations that already hold a copy.

One store defect was found by wiring this and fixed on the main database:
`custom.read_record` refused records `custom.read_records` had just listed,
because the one-record door asked a narrower question than its own list sibling.
It now asks `iam.has_access_for`, the platform's one access question
(`matrx-frontend/migrations/campaign/w6_ui_the_read_door_asks_the_one_access_question.sql`).

## 0.1.0

First release: `Grid`, `RecordForm`, `FieldEditor`, `TableSettings`,
`RelationPicker`, `Peek`, `ImportWizard`, `ExportMenu` and
`CustomFieldsSection`, plus the `RecordsUiProvider` rights port and the shared
refusal surface. Every one of them is proven headlessly against the rehearsal
branch by `pnpm test`.
